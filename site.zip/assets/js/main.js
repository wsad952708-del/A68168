(function () {
  // Sticky header shadow
  const header = document.getElementById('site-header');
  if (header) {
    const onScroll = () => {
      header.classList.toggle('scrolled', window.scrollY > 12);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  // Mobile drawer toggle
  const menuBtn = document.getElementById('menu-toggle');
  const drawer = document.getElementById('mobile-drawer');
  if (menuBtn && drawer) {
    menuBtn.addEventListener('click', () => {
      const open = drawer.classList.toggle('open');
      menuBtn.setAttribute('aria-expanded', String(open));
      document.body.style.overflow = open ? 'hidden' : '';
    });

    drawer.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        drawer.classList.remove('open');
        menuBtn.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      });
    });
  }

  // FAQ accordion
  document.querySelectorAll('.faq-q').forEach((btn) => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq-item');
      const isOpen = item.classList.toggle('open');
      btn.setAttribute('aria-expanded', String(isOpen));
    });
  });

  // Books expand/collapse
  const booksBtn = document.getElementById('books-toggle');
  const booksList = document.getElementById('books-list');
  if (booksBtn && booksList) {
    booksBtn.addEventListener('click', () => {
      const collapsed = booksList.classList.toggle('collapsed');
      booksBtn.textContent = collapsed ? '展開全部 17 本著作' : '收合書單';
    });
  }

  // Simple lightbox for awards / real photos
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightbox-img');
  const lightboxClose = document.getElementById('lightbox-close');
  if (lightbox && lightboxImg) {
    document.querySelectorAll('[data-lightbox]').forEach((el) => {
      el.addEventListener('click', () => {
        const src = el.getAttribute('data-lightbox') || el.querySelector('img')?.src;
        const alt = el.querySelector('img')?.alt || '';
        if (!src) return;
        lightboxImg.src = src;
        lightboxImg.alt = alt;
        lightbox.classList.add('open');
      });
    });

    const closeLb = () => lightbox.classList.remove('open');
    lightboxClose?.addEventListener('click', closeLb);
    lightbox.addEventListener('click', (e) => {
      if (e.target === lightbox) closeLb();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeLb();
    });
  }

  // Click-to-load Google Maps iframe (keeps Mobile Lighthouse Performance ~100 & TBT 0ms)
  const loadMapBtn = document.getElementById('load-google-map');
  const mapHolder = document.getElementById('map-facade');
  if (loadMapBtn && mapHolder) {
    loadMapBtn.addEventListener('click', () => {
      const iframe = document.createElement('iframe');
      iframe.className = 'embed-frame';
      iframe.style.height = '100%';
      iframe.style.minHeight = '420px';
      iframe.title = '阿添師高雄鳳山區文澄街101之4號地圖';
      iframe.referrerPolicy = 'no-referrer-when-downgrade';
      iframe.allowFullscreen = true;
      iframe.src = 'https://maps.google.com/maps?q=22.643965,120.349812&hl=zh-TW&z=17&output=embed';
      mapHolder.replaceWith(iframe);
    });
  }

  // Progressive load of below-the-fold CJK font subsets on first user interaction or idle
  const restFontHref = document.documentElement.dataset.restFonts;
  if (restFontHref) {
    let loaded = false;
    const loadRestFonts = () => {
      if (loaded) return;
      loaded = true;
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = restFontHref;
      document.head.appendChild(link);
    };
    ['scroll', 'pointerdown', 'touchstart', 'keydown', 'mousemove'].forEach((ev) => {
      window.addEventListener(ev, loadRestFonts, { once: true, passive: true });
    });
    const belowFold = document.querySelector('.quickfacts, .sec');
    if (belowFold && 'IntersectionObserver' in window) {
      const io = new IntersectionObserver((entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          loadRestFonts();
          io.disconnect();
        }
      }, { rootMargin: '200px 0px' });
      io.observe(belowFold);
    }
  }

  // One-tap copy LINE ID (0956522080)
  document.querySelectorAll('[data-copy-line]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-copy-line') || '0956522080';
      const orig = btn.dataset.origLabel || btn.textContent.trim();
      btn.dataset.origLabel = orig;
      const done = () => {
        btn.textContent = '✓ 已複製 LINE ID：' + id;
        setTimeout(() => { btn.textContent = orig; }, 2200);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(id).then(done).catch(() => {
          const ta = document.createElement('textarea');
          ta.value = id;
          ta.style.position = 'fixed';
          ta.style.opacity = '0';
          document.body.appendChild(ta);
          ta.select();
          try { document.execCommand('copy'); } catch (e) {}
          ta.remove();
          done();
        });
      } else {
        const ta = document.createElement('textarea');
        ta.value = id;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); } catch (e) {}
        ta.remove();
        done();
      }
    });
  });
})();
