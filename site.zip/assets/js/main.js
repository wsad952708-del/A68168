(function(){
const header=document.getElementById('site-header');
if(header){
  let ticking=false;
  window.addEventListener('scroll',()=>{
    if(!ticking){
      ticking=true;
      requestAnimationFrame(()=>{header.classList.toggle('scrolled',window.scrollY>12);ticking=false;});
    }
  },{passive:true});
}
const menuBtn=document.getElementById('menu-toggle');
const drawer=document.getElementById('mobile-drawer');
const closeDrawer=()=>{
  if(!drawer||!menuBtn)return;
  drawer.classList.remove('open');
  menuBtn.setAttribute('aria-expanded','false');
  document.body.style.overflow='';
};
if(menuBtn&&drawer){
  menuBtn.addEventListener('click',()=>{
    const open=drawer.classList.toggle('open');
    menuBtn.setAttribute('aria-expanded',String(open));
    document.body.style.overflow=open?'hidden':'';
  });
  drawer.querySelectorAll('a').forEach((link)=>{
    link.addEventListener('click',()=>{
      const href=link.getAttribute('href')||'';
      if(href.startsWith('#'))closeDrawer();
    });
  });
  window.addEventListener('pageshow',closeDrawer);
}
document.querySelectorAll('.faq-q').forEach((btn)=>{
  btn.addEventListener('click',()=>{
    const item=btn.closest('.faq-item');
    const isOpen=item.classList.toggle('open');
    btn.setAttribute('aria-expanded',String(isOpen));
  });
});
const booksBtn=document.getElementById('books-toggle');
const booksList=document.getElementById('books-list');
if(booksBtn&&booksList){
  booksBtn.addEventListener('click',()=>{
    const collapsed=booksList.classList.toggle('collapsed');
    booksBtn.textContent=collapsed?'展開全部 17 本著作':'收合書單';
  });
}
const lightbox=document.getElementById('lightbox');
const lightboxImg=document.getElementById('lightbox-img');
const lightboxClose=document.getElementById('lightbox-close');
if(lightbox&&lightboxImg){
  document.querySelectorAll('[data-lightbox]').forEach((el)=>{
    el.addEventListener('click',()=>{
      const src=el.getAttribute('data-lightbox')||el.querySelector('img')?.src;
      const alt=el.querySelector('img')?.alt||'';
      if(!src)return;
      lightboxImg.src=src;
      lightboxImg.alt=alt;
      lightbox.classList.add('open');
    });
  });
  const closeLb=()=>lightbox.classList.remove('open');
  lightboxClose?.addEventListener('click',closeLb);
  lightbox.addEventListener('click',(e)=>{if(e.target===lightbox)closeLb();});
  document.addEventListener('keydown',(e)=>{if(e.key==='Escape')closeLb();});
}
const loadMapBtn=document.getElementById('load-google-map');
const mapHolder=document.getElementById('map-facade');
if(loadMapBtn&&mapHolder){
  loadMapBtn.addEventListener('click',()=>{
    const iframe=document.createElement('iframe');
    iframe.className='embed-frame';
    iframe.style.height='100%';
    iframe.style.minHeight='420px';
    iframe.title='阿添師高雄鳳山區文澄街101之4號地圖';
    iframe.referrerPolicy='no-referrer-when-downgrade';
    iframe.allowFullscreen=true;
    iframe.src='https://maps.google.com/maps?q=22.643965,120.349812&hl=zh-TW&z=17&output=embed';
    mapHolder.replaceWith(iframe);
  });
}
// Load extra WOFF2 font slices ONLY AFTER all images finish loading (window.load), so 480 KB of fonts NEVER block photos on 4G!
const restFontHref=document.documentElement.dataset.restFonts;
if(restFontHref){
  let loaded=false;
  const loadRestFonts=()=>{
    if(loaded)return;
    loaded=true;
    const link=document.createElement('link');
    link.rel='stylesheet';
    link.href=restFontHref;
    document.head.appendChild(link);
  };
  if(document.readyState==='complete'){setTimeout(loadRestFonts,100);}
  else{
    window.addEventListener('load',()=>setTimeout(loadRestFonts,150),{once:true});
    setTimeout(loadRestFonts,3500);
  }
}
document.querySelectorAll('[data-copy-line]').forEach((btn)=>{
  btn.addEventListener('click',()=>{
    const id=btn.getAttribute('data-copy-line')||'0956522080';
    const orig=btn.dataset.origLabel||btn.textContent.trim();
    btn.dataset.origLabel=orig;
    const done=()=>{
      btn.textContent='✓ 已複製 LINE ID：'+id;
      setTimeout(()=>{btn.textContent=orig;},2200);
    };
    if(navigator.clipboard&&navigator.clipboard.writeText){
      navigator.clipboard.writeText(id).then(done).catch(()=>{
        const ta=document.createElement('textarea');
        ta.value=id;ta.style.position='fixed';ta.style.opacity='0';
        document.body.appendChild(ta);ta.select();
        try{document.execCommand('copy');}catch(e){}
        ta.remove();done();
      });
    }else{
      const ta=document.createElement('textarea');
      ta.value=id;ta.style.position='fixed';ta.style.opacity='0';
      document.body.appendChild(ta);ta.select();
      try{document.execCommand('copy');}catch(e){}
      ta.remove();done();
    }
  });
});
// Instant navigation prefetcher on touchstart / pointerenter
const prefetched=new Set();
const warmUrl=(href)=>{
  if(!href||prefetched.has(href))return;
  try{
    const u=new URL(href,location.href);
    if(u.origin!==location.origin||u.pathname===location.pathname)return;
    prefetched.add(href);
    const l=document.createElement('link');
    l.rel='prefetch';l.as='document';l.href=u.href;
    document.head.appendChild(l);
    fetch(u.href,{credentials:'same-origin',priority:'low'}).catch(()=>{});
  }catch(e){}
};
document.addEventListener('touchstart',(e)=>{
  const a=e.target&&e.target.closest?e.target.closest('a[href]'):null;
  if(a)warmUrl(a.getAttribute('href'));
},{passive:true});
document.addEventListener('pointerenter',(e)=>{
  const a=e.target&&e.target.closest?e.target.closest('a[href]'):null;
  if(a)warmUrl(a.getAttribute('href'));
},true);
const warmCss=document.documentElement.dataset.warmCss;
if(warmCss){
  const doWarm=()=>{
    const l=document.createElement('link');
    l.rel='prefetch';l.as='style';l.href=warmCss;
    document.head.appendChild(l);
    fetch(warmCss,{credentials:'same-origin',priority:'low'}).catch(()=>{});
  };
  window.addEventListener('load',()=>setTimeout(doWarm,300),{once:true});
}
})();